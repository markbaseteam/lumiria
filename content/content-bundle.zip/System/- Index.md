---
dg-publish: true
title: System
---
# System

Lumiria primarily uses [Cairn](https://cairnrpg.com/) for its roleplaying system, with additional hacks and homebrewed rules to fill out anything extra that we need. 

For player ease all of the rules and information are available within these pages. If something is not credited properly or you wrote it and wish it to be removed please let us know. 

## Credits
- [Cairn RPG](https://cairnrpg.com/) by [Yochai Gal](https://newschoolrevolution.com).