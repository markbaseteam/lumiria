---
dg-publish: true
tags: creature/type/humanoid creature/ability/weapons creature/ability/magic 
---
# Acolyte

4 HP, 1 Armor, 14 WIL, mace (d8) or ceremonial dagger (d6), Holy Symbol (_Ward_ once per day)

- Holy men & women bound to a particular deity.
- Normally travel in groups of 4+.
