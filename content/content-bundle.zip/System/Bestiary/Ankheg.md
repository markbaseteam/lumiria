---
dg-publish: true
tags: creature/type/insectoid
---
# Ankheg

7 HP, 1 Armor, 16 STR, 8 WIL, bite (d10), acid squirt (d8, _blast_)

- Huge insectoids with multiple legs and shiny black eyes. It Subsists from dirt, roots, and flesh.
- Burrows just beneath the surfaces to ambush unsuspecting creatures.
