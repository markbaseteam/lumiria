---
dg-publish: true
tags: creature/type/wild-animal creature/type/primate creature/type/mammal 
---
# Ape, White

5 HP, 14 STR, claws (d6+d6), rocks (d6, _blast_)

- Albino gorillas with nocturnal habits.
- Defend their territory with threatening gestures, followed by sudden violence.
