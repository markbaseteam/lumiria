---
dg-publish: true
tags: creature/type/arachnid creature/type/insectoid 
---

# Aranea

6 HP, 12 DEX, 15 WIL, bite (d6), two random spellbooks

- 6’ long, intelligent spiders of greenish-black coloration. Have an odd lump on the back, housing its large brain. Two front legs have digits, allowing an aranea to grasp tools. Dwell in web-filled lairs where they conduct magical research.
- Scared of fire, avoid spells of such effect.
- Creatures caught in its webs are entangled and unable to move. Breaking free requires an STR save.
