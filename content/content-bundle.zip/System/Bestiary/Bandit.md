---
dg-publish: true
tags: creature/type/humanoid 
---

# Bandit

4 HP, 11 STR, 14 DEX, 12 WIL, dagger (d6)

- Thieves who value wealth over all else.
- Use disguises, stealth, and trickery to surprise victims.
