---
dg-publish: true
tags: creature/type/humanoid creature/type/spirits creature/ability/magic
---

# Banshee

8 HP, 3 Armor, 6 STR, 12 DEX, 15 WIL, ghostly touch (d8)

- Incorporeal spirits that long after death to haunt the living.
- Unharmed by cold, heat, or the elements.
- **Wail**: Anyone in earshot must make a WIL save or fall unconscious.
