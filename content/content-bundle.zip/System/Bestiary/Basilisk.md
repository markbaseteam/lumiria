---
dg-publish: true
tags: creature/type/reptilian creature/type/serpent creature/ability/magic 
---

# Basilisk

10 HP, 1 Armor, 12 STR, 13 DEX, 13 WIL, bite (d10)

- Long, serpentine lizards that nest deep below the earth or in brambles just underfoot. 
- **Gaze**: A PC meeting the Basilisk's gaze must make a WIL save or turn instantly to stone. Its reflection is harmless.
- Fighting a **Basilisk** without meeting its gaze is difficult (direct attacks are __impaired__).
