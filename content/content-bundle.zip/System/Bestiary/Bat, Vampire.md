---
dg-publish: true
tags: creature/type/bat creature/type/wild-animal creature/ability/flying creature/type/mammal
---

# Bat, Vampire

3 HP, 6 STR, 14 DEX,  bite (d8)

- Large, nocturnal mammals that feed on the blood of their victims. 
- Unaffected by darkness or blinding effects. Loud noises and holy rituals may frighten them.
- **Critical Damage**: Recovers full STR and HP if the target has blood.
