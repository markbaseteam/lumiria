---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal creature/type/bear
---

# Bear, Black

6 HP, 14 STR, 12 DEX, 6 WIL, claws (d6+d6), bite (d8)

- 4' tall bears (twice that much if standing) that subsist mostly on berries and roots. Drawn to campsites in search of food.  
- Aggressive if cornered or feel that their young are threatened. 