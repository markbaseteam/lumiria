---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal creature/type/bear 
---

# Bear, Cave

8 HP, 17 STR, 13 DEX, 8 WIL, claws (d10+d10), bite (d12)

- Ferocious, 15’ tall carnivorous bears. Make their dens in caves. 
- Excellent trackers despite their poor eyesight, relying on their keen their sense of smell.
- **Hug**: On **Critical Damage**, the target loses an additional d6 damage as they are squeezed into a pulp.
