---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal creature/type/bear 
---

# Bear, Grizzly

6 HP, 15 STR, 13 DEX, 5 WIL, claws (d8+d8), bite (d10)

- Aggressive, 9’ tall reddish-brown bears found in mountains, woodlands, and prairies. 
- They prefer to eat fish and meat, and are not opposed to attacking the rare unfortunate to cross their path.
