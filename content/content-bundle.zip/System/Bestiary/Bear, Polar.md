---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal creature/type/bear 
---

# Bear, Polar

7 HP, 16 STR, 12 DEX, 6 WIL, claws (d8+d8), bite (d10)

- 11’ tall white-furred bears who live in cold regions, subsisting mostly from fish.
- Excellent swimmers that also move effortlessly through both snow and ice.