---
dg-publish: true
tags: creature/type/insect
---

# Beetle, Tiger

3 HP, 6 STR, 12 DEX, 6 WIL, bite (d6)

- 4’ long striped carnivorous insect with powerful mandibles. 
- Prefers smaller prey but will not shy from hunting the occasional humanoid.
