---
dg-publish: true
tags: creature/type/humanoid creature/ability/weapons 
---

# Berserker

10 HP, 1 Armor, 14 STR, 13 DEX, 15 WIL, twin axes (d8+d8)

- Ruthless warriors that derive their power from the skins they wear: bears, wolves, boards, etc.
- Ignores the **Morale** rule and is never treated as part of a _detachment_.
- **Rage**: The Berserker enters a state of pure fury, their attacks gaining the __enhanced__ and _blast_ quality until they take STR damage.
