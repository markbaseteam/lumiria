---
dg-publish: true
tags: creature/type/mammal creature/type/canine 
---

# Blink Dog

5 HP, 11 STR, 14 DEX, 5 WIL, bite (d6)

- Intelligent, wild dogs that travel in packs.
- After each attack, they may teleport a safe distance away.
