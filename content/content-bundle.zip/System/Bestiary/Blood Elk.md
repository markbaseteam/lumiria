---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal 
---

# Blood Elk

4 HP, 12 STR, 13 DEX, 5 WIL, horns (d8)

- Born from a wound caused by a greedy or selfesh act that has been left to fester.
- Attacks & kills to eat meat, but gains no sustenance.
- **Critical Damage**: gores its victims by ripping out their entrails.
