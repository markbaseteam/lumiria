---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal 
---

# Boar

3 HP, 12 STR, 6 WIL, tusks (d6)

- Omnivorous wild boars that dwell primarily in forests.
- Not naturally aggressive, but dangerous if disturbed.
- **Critical Damage**: Gores its victims, causing great loss of blood.
