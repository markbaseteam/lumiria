---
dg-publish: true
tags: creature/ability/magic  creature/type/magical
---

# Boggart

3 HP, 4 STR, 17 DEX, 13 WIL

- A wild, hairy trickster that takes pleasure in being a minor nuisance.
- Prizes relics and shiny trinkets above all else but unwilling to trade for coin.
- Boggarts have names that describe their true nature. Knowing their true name allows one to control a Boggart.
