---
dg-publish: true
tags: creature/type/humanoid creature/ability/weapons 
---

# Brigand

4 HP, 1 Armor, 12 STR, 12 DEX, 9 WIL, shortsword (d6) or short bow (d6)

- Outlaws and mercenaries who raid settlements and ambush travelers. Travel in large groups of at least one _detachment_.
- A detachment always travels with one leader wearing chainmail or similar (2 Armor) and a longsword (d8) or crossbow (d8).
- When testing Morale, save using the leader's WIL (13). If the leader dies, the Brigands will flee.
