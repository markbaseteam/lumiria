---
dg-publish: true
tags: creature/type/humanoid creature/ability/weapons 
---

# Buccaneer

4 HP, 11 STR, 14 DEX, 12 WIL, scimitar (d6)

- Outlaw sailors who raid coastal settlements, as well as other ships.
- Travel in large ship crews, only fighting in clear advantage (generally numerical).
