---
dg-publish: true
tags: creature/type/magical 
---

# Bugbear

4 HP, 1 Armor, 14 STR, 12 DEX, 11 WIL, club (d8, bulky)

- Large, goblinoids covered in animal-like hair.
- Prefers stealth and trickery to gain an advantage.
