---
dg-publish: true
tags: creature/type/wild-animal creature/type/domestic-animal
---

# Camel

3 HP, 12 STR, 13 DEX, 4 WIL, bite (d6)

- Beasts of burden native to dry, arid lands.
- Can survive without water for weeks at a time.
- Moves through sand and broken ground without difficulty.
