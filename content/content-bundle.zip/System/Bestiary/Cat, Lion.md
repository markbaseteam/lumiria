---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal creature/type/feline
---

# Cat, Lion

5 HP, 12 STR, 12 DEX, 11 WIL, bite (d10), claws (d6+d6)

- Hunts in a pride of at least 4. Lives in the savannahs or other similarly dry lands.
- Carnivorous. Only hunts humans if desperatly hungry or in clear advantage.
- **Blood-sense**: Can follow bleeding prey over great distances. 
