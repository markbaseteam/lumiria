---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal creature/type/feline 
---

# Cat, Panther

4 HP, 11 STR, 14 DEX, 5 WIL, bite (d8), claws (d6+d6)

- Dark-furred cats that live on forests and plains.
- Hunts medium or small-sized animals, using their extreme speed and night vision to their advantage.
