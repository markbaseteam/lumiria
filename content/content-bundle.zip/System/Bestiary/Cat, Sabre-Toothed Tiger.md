---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal creature/type/feline 
---

# Cat, Sabre-Toothed Tiger

8 HP, 15 STR, 14 DEX, 3 WIL, bite (d12), claws (d6+d6)

- Huge, primeval cats with enormous fangs.
- Extremely rare, generally found in regions untouched by civilization.
