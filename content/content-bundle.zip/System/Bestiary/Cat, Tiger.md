---
dg-publish: true
tags: creature/type/wild-animal creature/type/mammal creature/type/feline 
---

# Cat, Tiger

6 HP, 14 STR, 14 DEX, 6 WIL, bite (d8), claws (d6+d6)

- Striped, solitary felines. Lives in woodlands and in colder regions.
- Uses camouflage and stealth to hunt and surprise their victims.
