---
dg-publish: true
tags: creature/type/magical creature/type/monsterous
---

# Catoblepas

7 HP, 1 Armor, 16 STR, 9 DEX, 13 WIL, tail (d8)

- A monstrous creature with the body of a Cape buffalo, scales on its back, and the head of a wild boar. Its enormous head always points towards te ground.
- **Paralyze**: Its stare turns a single target to stone. Moonlight reverses the effect.   

