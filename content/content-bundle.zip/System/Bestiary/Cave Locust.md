---
dg-publish: true
tags: creature/type/insectoid 
---

# Cave Locust

2 HP, 6 STR, 12 DEX, 6 WIL, bite (d4)

- Giant, herbivorous crickets that dwell in caves. Blends into stone due to their natural coloration.
- Emits loud shrieks when threatened that can be heard from very far away.
- Immune to most types of poison.
