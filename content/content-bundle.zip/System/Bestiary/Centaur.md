---
dg-publish: true
tags: creature/type/humanoid creature/type/mammal 
---

# Centaur

6 HP, 1 Armor, 14 STR, 12 DEX, spear (d8) or short bow (d6)

- Creatures with the lower body and legs of a horse and the upper body, arms and head of a humanoid.
- Uses their great speed to hunt for food in the forest and plains.