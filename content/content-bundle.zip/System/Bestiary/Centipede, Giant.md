---
dg-publish: true
tags: creature/type/insect 
---

# Centipede, Giant

1 HP, 6 STR, 3 WIL, sting (d6)

- 2’ long centipedes that live in damp, underground places.
- Generally shy, but will attack if approached. 
- **Critical Damage**: the venom renders the target _deprived_ for up to 10 days (save STR once a day to recover).
