---
dg-publish: true
tags: creature/type/monsterous creature/type/aberration creature/ability/magic 
---

# Chimera

10 HP, 14 STR, bite and gore (d10+d10), fire breath (d12, _blast_)

- A three-headed flying aberration.A hybrid of lion, goat, and dragon.
- Created through powerful magic, these creatures are can be bound to a master or roaming free.
