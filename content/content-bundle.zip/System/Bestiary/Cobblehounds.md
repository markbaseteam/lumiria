---
dg-publish: true
tags: creature/type/construct
---

# Cobblehounds

12 HP, 2 Armor, 14 STR, 1 DEX, 8 WIL, bite (d10)

- Immobile constructs typically used as guardians to great tombs or artefacts.
- Unaffected by mundane persuasion techniques, but does love a good bone.
