---
dg-publish: true
tags: creature/type/magical creature/type/monsterous 
---

# Cockatrice

5 HP, 8 STR, 14 DEX, beak (d6)

- Small creatures resembling chickens with reptilian features.
- Notably agile and hard to pin down, their greatest enemy is the weasel.
- **Critical Damage**: the victim is turned to stone until the Cockatrice is killed.
