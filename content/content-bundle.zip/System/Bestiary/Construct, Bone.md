---
dg-publish: true
tags: creature/type/construct creature/type/humanoid 
---

# Bone Construct

8 HP, 2 Armor, 15 STR, 8 WIL, sharpened arms (d8, blast)

- 6’ tall humanoid constructs made of bone and sorcery. Four-armed, with sharpened ends spread around their torso.
- Mindless guardians, they simply detect and attack any living creature besides their creator.
- Mundane attacks are _impaired__ against the construct.
