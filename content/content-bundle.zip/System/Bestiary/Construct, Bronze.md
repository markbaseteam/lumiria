---
dg-publish: true
tags: creature/type/construct creature/type/humanoid 
---

# Bronze Construct

15 HP, 3 Armor, 18 STR, 6 DEX, fists (d10+d10), _detachment_

- Towering humanoid constructs made of pure bronze. Resemble old men with long beards and hair, and emanate a strong heat.
- Immune to fire and heat. Mundane attacks are __impaired__.
- If it takes **Critical Damage** from bladed weapons it spurts a burning liquid, doing d12 _blast_ damage.