---
dg-publish: true
tags: creature/type/construct creature/type/humanoid 
---

# Flesh Construct

9 HP, 1 Armor, 15 STR, 8 DEX, 8 WIL, fists (d10+d10)

- 7’ tall bloated humanoid abominations made of flesh stitched together.
- Mundane attacks, fire, and cold attacks are _impaired_ against it.
- **Absorb Lightning**: If the construct is ever hit by electricty, it fully recovers oth HP and STR, and its next attacks are _enhanced_. 
