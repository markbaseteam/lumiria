---
dg-publish: true
tags: creature/type/construct creature/type/humanoid 
---

# Iron Construct

18 HP, 3 Armor, 18 STR, 8 WIL, sword (d12+d12)

- 12’ humanoid statues forged of metal, fire, and magic. Wield massive swords of iron.
- Immune to mundane attacks, electricity, and cold. Fire damage is absorbed, and heals any lost STR.
- **Poison Gas**: Releases a cloud of poisonous gas (d4 STR damage to all nearby). Anyone breathing the gas must also pass a STR save or die of toxic death.
