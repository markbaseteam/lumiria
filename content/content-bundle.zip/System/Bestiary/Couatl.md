---
dg-publish: true
tags: creature/type/serpent creature/type/monsterous 
---

# Couatl

9 HP, 6 STR, 12 DEX, 15 WIL, bite (d6)

- Long, feathered serpents with colorful wings. Live in hot jungles, and are considered divine by some civilizations.
- Highly intelligent and magical, they are capable of speaking any language.
- Can shapechange into the form of a person or small animal.
