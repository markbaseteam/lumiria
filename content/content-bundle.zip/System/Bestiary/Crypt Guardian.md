---
dg-publish: true
tags: creature/type/humanoid 
---

# Crypt Guardian

12 HP, 12 STR, 11 DEX, 14 WIL, ethereal claws (d8)

- An animated skeleton clothed in billowing robes. Its eye sockets are hypnotically red. Defends crypts & tombs, and will not attack if left undisturbed.
- Non-magical attacks against it are _impaired_.
- Can teleport any target in eyesight to a random room nearby.
