---
dg-publish: true
tags: creature/type/monsterous 
---

# Cyclops

9 HP, 18 STR, 8 DEX, 6 WIL, club (d10)

- Giant humanoids with a single large eye centered on the face. Dwell in caves and herd small animals.
- Slow-witted, can easily be fooled by other intelligent beings.
