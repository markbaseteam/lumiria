---
dg-publish: true
tags: creature/type/monsterous 
---

# Deep One

6 HP, 12 WIL, spear (d8)

- Amphibious, fish-like humanoids with webbed fingers. Live in deep seas and are able to see in the darkness.
- Highly resistant to magical effects.
- Occasionally surface to trade with coastal settlements, frequently requesting union between one of them and a human.
