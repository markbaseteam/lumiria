---
dg-publish: true
tags: creature/type/monsterous 
---

# Demonic Knight

12 HP, 3 Armor, 16 STR, 8 DEX, 12 WIL, longsword (d10)

- Once holy warriors who fell to the temptation of dark powers that they now serve in undeath. Rides nightmarish steeds into battle.
- Lesser undead creatures mindlessly follow their command.
- Their evil aura frightens anyone who comes into melee range.
- **Critical Damage**: Everyone who sees the knight landing the blow is driven into bloodthirsty hatred.
