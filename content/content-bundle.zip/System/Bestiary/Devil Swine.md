---
dg-publish: true
tags: creature/type/humanoid creature/type/monsterous 
---

# Devil Swine

9 HP, 16 STR, 8 DEX, gore (d6+d6)

- Corpulent humans who can change into massive swine. Lurk in isolated human settlements, hunting the people to eat their flesh.
- Can only shape change at night, hunt in the dark, surprising victims.
- **Critical Damage**: A human victim gets infected, becoming a lycanthrope of the same type after a couple of weeks.
