---
dg-publish: true
tags: creature/type/magical 
---

# Djinn

10 HP, 1 Armor, 15 DEX, fists (d10+d8)

- Tall, cloudy humanoids from the plane of air. Highly intelligent, use invisibility and illusions to trick other beings.
- May transform into a whirlwind, sweeping everything on its path.
- Capable of granting a wish per person, the result always is distorted based on the wording of the wish.
