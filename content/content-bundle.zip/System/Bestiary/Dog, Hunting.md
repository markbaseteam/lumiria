---
dg-publish: true
tags: creature/type/canine creature/type/domestic-animal 
---

# Dog, Hunting

3 HP, 12 DEX, bite (d6)

- Bulky, domestic breeds with a ferocious nature.
- Track by scent. Once started, very difficult to put off the trail.
- Only attack at their owner’s command.
