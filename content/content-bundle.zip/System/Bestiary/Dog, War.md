---
dg-publish: true
tags: creature/type/domestic-animal creature/type/canine 
---

# Dog, War

6 HP, 1 Armor, 13 STR, bite (d10)

- Large breeds selected by their bulk and strength.
- Not scared by noise or battle.
- Trained to fight until death if not ordered to stop.
