---
dg-publish: true
tags: creature/type/canine creature/type/wild-animal 
---

# Dog, Wild

3 HP, 12 DEX, bite (d6)

- Wild dogs that roam in forests in large packs.
- A Wild dog automatically succeeds Morale saves while among its pack.
