---
dg-publish: true
tags: creature/type/monsterous creature/type/draconic creature/type/reptilian 
---

# The Black Dragon

16 HP, 1 Armor, 13 STR, 18 DEX, 14 WIL, bite (d12), claws (d10+d8), _detachment_

- A giant amphibious reptile with glossy black scales. Dwells in swamps and other hostile flooded environments.
- Extremely cruel and violent, makes use of the dark, difficult environment and its surprising agility to separate its victims and kill them one by one.
- Any critical damage saves provoked by the dragon's bite automatically fail, due to its powerful acidic saliva.
