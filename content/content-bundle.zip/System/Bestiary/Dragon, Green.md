---
dg-publish: true
tags: creature/type/monsterous creature/type/draconic creature/type/reptilian 
---

# The Green Dragon

12 HP, 2 Armor, 14 STR, 15 DEX, 18 WIL, bite (d12), venom spit (d8, blast), __detachment__

- 50 ft long serpentine creature with spiked scales. Dwell in dense forests, staying atop the trees to attack it's victims from above. 
- Trick victims to obey it's commands in exchange for their lives, only to devour them anyway when they're no longer useful.  
- **Critical Damage**: The poison takes hold of the victim's body, killing it if an antidote isn't applied within one day.
