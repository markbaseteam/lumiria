---
dg-publish: true
tags: creature/type/monsterous creature/type/draconic creature/type/reptilian 
---

# Metallic Dragon

15 HP, 3 Armor, 18 STR, 13 DEX, 16 WIL, bite (d12+d10), _detachment_

- Majestic draconic beings with shiny metallic scales. Said to be created by a Red Dragon embraced by divine power. Feed on precious metals like gold, silver or copper, with its scales matching the metal it has eaten the most.
- Master shapechangers, can take the form of any humanoid or animal.
- **Gas Cloud**: Breathes a thick cloud of white hot smoke, dealing d12 damage to all caught and leaving them drowsy and slowed. It needs a short rest before being able to do this again.
