---
dg-publish: true
tags: creature/type/monsterous creature/type/draconic creature/type/reptilian 
---

# The Red Dragon

18 HP, 3 Armor, 18 STR, 12 DEX, 16 WIL, bite (d12), claws (d10+d8), _detachment_

- A gargantuan flaming creature, it's wingspan over a hundred feet. Arrogant and greedy, sees everything as its possession and everyone as its servant. Lairs within mountains with high volcanic activity.
- Made of pure fire, is completely unharmed by any form of heat. Any cold vanishes within its presence.
- **Fire Breath**: The dragon breathes a massive cone of pure flame dealing 12 damage (no roll) to all caught, the flame ignores and destroys any mundane armor. It needs a short rest before being able to do this again.
