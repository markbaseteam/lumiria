---
dg-publish: true
tags: creature/type/monsterous creature/type/draconic creature/type/reptilian 
---

# Dragon Turtle

15 HP, 3 Armor, 18 STR, 6 DEX, 12 WIL, bite (d12+d12), _detachment_

- Gargantuan sea monsters with the shell of a turtle and draconic features. Lurk in deep oceans and can be mistaken for a small island when on the surface.
- Attack ships, sinking them to add any treasure to their massive underwater hoards.
- Breathes massive clouds of steam, clogging visions and damaging all inside for d10 damage.
