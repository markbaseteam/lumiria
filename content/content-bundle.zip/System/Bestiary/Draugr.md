---
dg-publish: true
tags: creature/type/undead
---

# Draugr

12 HP, 2 Armor, 15 STR, 9 DEX, 13 WIL, rusty broadsword (d8)

- Undead horror made of withered flesh. Rises from those killed in battle and left to rot.
- **Critical Damage**: target is instantly killed, only to rise later as a Thrall.
