---
dg-publish: true
tags: creature/type/insect 
---

# Driver Ant

3 HP, 12 DEX, bite (d6)

- Giant, omnivorous black ants that build their colonies deep underground.
- When hungry, they will consume anything in their path.
- Once in melee combat, it will not stop attacking its victim until dead.
