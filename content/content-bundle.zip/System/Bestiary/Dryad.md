---
dg-publish: true
tags: creature/type/spirits creature/type/magical 
---

# Dryad

4 HP, 14 WIL, unarmed (d4)

- Shy, peaceful tree spirits whose manifest in a beautiful female form.
- Spiritually bound with a tree, may disappear by joining with the tree again. Can’t go too far away from it and dies if the tree is destroyed.
- Charm strangers that come near. Charmed creatures mindlessly walk into the tree, disappearing forever if not rescued quickly.
