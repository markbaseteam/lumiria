---
dg-publish: true
tags: creature/type/humanoid 
---

# Dwarf

4 HP, 2 Armor, 14 STR, hammer (d8)

- Short, bulky, humanoids with tough skin like earth and stone. Dwell in mountains and underground.
- Do not rely on light, being able to see shapes and heat patterns in darkness.
- Highly resistant to poison and disease.
