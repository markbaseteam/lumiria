---
dg-publish: true
tags: creature/type/elemental
---

# Elemental, Air

16 HP, 11 STR, 15 DEX, 8 WIL, wind blow (d10)

- Huge, living vortexes of whirling air.
- Lighter creatures are swept away by its presence.
- It's attacks ignore any worn armor. 
