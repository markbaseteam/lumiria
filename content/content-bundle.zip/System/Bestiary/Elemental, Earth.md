---
dg-publish: true
tags: creature/type/elemental 
---

# Elemental, Earth

12 HP, 3 Armor, 16 STR, 6 DEX, fists (d12)

- Huge humanoid beings made of earth and stone.
- Create constant earth tremors with their presence.
- Can meld into the earth and move through it as if swimming.
