---
dg-publish: true
tags: creature/type/elemental 
---

# Elemental, Fire

16 HP, 12 DEX, 14 WIL, flare (d10, blast)

- Living columns of pure flame that burn everything in their path.
- Highly vulnerable to being touched by water or rain.
- Can scatter their flames, freely changing its form.
