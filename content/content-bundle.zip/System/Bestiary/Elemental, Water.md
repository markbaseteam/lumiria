---
dg-publish: true
tags: creature/type/elemental 
---

# Elemental, Water

12 HP, 2 Armor, 15 STR, blow (d8)

- Huge waves of flowing water.
- Must stay near a body of water.
- Envelop victims inside their forms to drown then.
