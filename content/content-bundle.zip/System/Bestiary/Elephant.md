---
dg-publish: true
tags: creature/type/wild-animal 
---

# Elephant

9 HP, 16 STR, 6 DEX, tusks (d10)

- Large tusked animals that dwell near hot forests.   Found both alone and in herds.
- With enough open ground for a clear run, it will charge its victims, enhancing damage.
- Its tusks can be sold for high amounts of gold if removed whole.
