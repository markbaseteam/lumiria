---
dg-publish: true
tags: creature/type/humanoid 
---

# Frost Elf

14 HP, 1 Armor, 8 STR, 13 DEX, 14 WIL, icicle dagger (d6), a Spellbook (Choose one: Sleep, Teleport, Detect Magic)

- Beautiful, amoral, and long-lived.
- Resistant to most forms of magic.
