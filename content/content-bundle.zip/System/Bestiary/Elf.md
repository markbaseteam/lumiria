---
dg-publish: true
tags: creature/type/humanoid 
---

# Elf

4 HP, 1 Armor, 8 STR, 14 DEX, 14 WIL, shortswords (d6+d6) or longbow (d8), a Spellbook (choose one: Charm or Detect Magic)

- Slender, long-lived, fey humanoids with pointed ears. Live in harmony with nature, adapting to it instead of conquering.
- Highly resistant to charming and mind-controlling effects.
