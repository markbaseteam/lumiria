---
dg-publish: true
tags: creature/type/humanoid creature/type/shapeshifter creature/type/magical 
---

# Estrie

10 HP, 11 STR, 15 DEX, 14 WIL, draining hair (1d8)

- Appears as a woman with long dark hair that extends all the way to her feet.
- Can transform into owls, but only at night. Their shriek is ear-piercing.
- Drinking blood gives them power, but they can obtain sustenance from eating bread and salt if taken from those they have wronged.
- Binding their hair prevents their transformation. They can be killed, but their head must then be buried, the mouth stuffed with dirt.
- **Critical Damage**: target falls unconscious for 1d4 days.

