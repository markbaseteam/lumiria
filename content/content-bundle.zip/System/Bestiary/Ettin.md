---
dg-publish: true
tags: creature/type/humanoid creature/type/monsterous 
---

# Ettin

10 HP, 16 STR, 6 WIL, club (d10)

- Two-headed giant kin of low intelligence and aggressive behaviour.   Lay underground and only act in darkness.
- One head is always vigilant, preventing being surprised.
