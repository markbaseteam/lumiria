---
dg-publish: true
tags: creature/type/monsterous 
---

# Eye of Terror

15 HP, 8 DEX, 18 WIL, bite (d8+d8)

- Floating spheres with a large maw, one big central eye, and several small eyes on stalks scattered through the body.   Scheming and greedy, lair deep underground.
- Cancels any magic effect in a nearby range facing its central eye.
- The eyestalks cast one of those spells each round randomly: (1-Charm, 2-Phobia, 3-Telekinesis, 4-Sleep, 5-Shuffle, 6-Vision).
