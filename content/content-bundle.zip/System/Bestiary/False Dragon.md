---
dg-publish: true
tags: creature/type/draconic creature/type/reptilian 
---

# False Dragon

4 HP, 8 STR, 14 DEX, 12 WIL, sting (d6)

- Tiny winged draconic creatures with a sting-tipped tail and reddish scales. Found in forests and caverns.
- Capable of communicating telepathically with nearby creatures.
- **Critical Damage**: The sting's poison leaves the victim in a comatose state for 1d6 days.
