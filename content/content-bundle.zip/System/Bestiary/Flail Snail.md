---
dg-publish: true
tags: creature/type/monsterous 
---

# Flail Snail

4 HP, 2 Armor, 14 STR, 6 DEX, tentacles (d8+d8)

- Giant snails with heavy, club-like tentacles and a colorful shell.   Dwell underground.
- Its colorful shell can deflect magic, possibly annulling it or reflecting it to its caster.
