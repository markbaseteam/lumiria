---
dg-publish: true
tags: creature/type/humanoid creature/type/monsterous 
---

# Foxwoman

6 HP, 12 STR, 14 DEX, 11 WIL, teeth (d6), claws (d8+d8)

- Appears as a 7-foot tall with a human woman with the head of a fox.
- Transforms into a fox at will.
