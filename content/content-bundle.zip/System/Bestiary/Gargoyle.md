---
dg-publish: true
tags: creature/type/magical creature/type/monsterous 
---

# Gargoyle

8 HP, 3 Armor, 14 STR, 6 DEX, 12 WIL, claws (d8+d6)

- Magical creatures that look like monstrous, horned, winged statues.
- Guard places by standing still to pass like inanimate statues and attacking what comes near.
- Cannot be charmed and put to sleep.
