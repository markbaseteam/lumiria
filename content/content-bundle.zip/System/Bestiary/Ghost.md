---
dg-publish: true
tags: creature/type/spirits 
---

# Ghost

8 HP, 15 WIL, cold touch (d4)

- Incorporeal spirits of the restless dead. Avoids direct confrontation, instead it quietly posesses a target and acts through them when possible.
- Immune to most forms of damage, only suscetible to magic and holy water. 
- **Posession**: One target must save WIL or be posessed, being controlled by the ghost until it's somehow driven off. 
