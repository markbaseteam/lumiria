---
dg-publish: true
tags: creature/type/undead creature/type/magical 
---

# Ghoul

6 HP, 14 STR, 3 WIL, elongated claws jagged teeth (d8+d6)

- Grey-skinned man-things wearing shredded clothes, hunkering over the ground.
- Craves the flesh of the living, as it grows only more powerful with each victim.
- **Critical Damage**: target is paralyzed. The wound turns fatal in a day if not treated by a priest or skilled healer. If not burned, the body will rise as a Ghoul.
