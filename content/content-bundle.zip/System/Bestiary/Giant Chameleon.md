---
dg-publish: true
tags: creature/type/reptilian creature/type/monsterous 
---

# Giant Chameleon

6 HP, 14 STR, 12 WIL, bite (d8)

- 7' long lizards that camouflage by changing the color of their scales.
- Use their camouflage to surprise victims.
- Can attack further away targets by grabbing them with their elongated tongue. The victim must save STR or be pulled to the lizard's mouth and bitten.
