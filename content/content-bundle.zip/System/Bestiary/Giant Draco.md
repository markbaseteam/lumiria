---
dg-publish: true
tags: creature/type/reptilian creature/type/monsterous 
---

# Giant Draco

6 HP, 14 STR, 14 DEX, bite (d10)

- 6' long carnivorous lizards with skin flaps between legs that allow gliding.
- Dwell mostly on the surface, but sometimes can be found underground.
- Hunt by waiting atop tall places and gliding down to surprise targets.
