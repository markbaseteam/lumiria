---
dg-publish: true
tags: creature/type/reptilian creature/type/monsterous creature/type/magical 
---

# Giant Flame Lizard

8 HP, 14 STR, 12 WIL, bite (d8+d6) or fire breath (d6,blast)

- 30' long grey and red lizards that are sometimes mistaken by dragons. 
- Lair underground where they sleep most of the day, but hunt on the surface.
- Unharmed by flames and heat.
- Their eggs can be sold for a high price.
