---
dg-publish: true
tags: creature/type/monsterous 
---

# Giant Piranha

7 HP, 15 DEX, bite (d10)

- 5’ long piranhas with colorful scales.   Live in rivers and attack anything in the water.
- Dwell in groups and overwhelm victims by swarming them.
- Once it smells blood, it will not stop attacking.
