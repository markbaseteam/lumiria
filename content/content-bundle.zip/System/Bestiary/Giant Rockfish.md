---
dg-publish: true
tags: creature/type/monsterous 
---

# Giant Rockfish

5 HP, 1 Armor, 12 STR, spine (d6)

- Spiny fish with rock-like scales. Live in saltwater. Normally passive, but attacks if disturbed.
- Camouflages in rocks and coral formations.
- **Critical Damage**: The spines release a highly lethal venom (d8 extra STR damage).
