---
dg-publish: true
tags: creature/type/monsterous creature/type/humanoid 
---

# Cloud Giant

14 HP, 1 Armor, 16 STR, 12 DEX, 18 WIL, mace (d10+d10), __detachment__

- 20’ tall humanoids with hair and skin in tones of grey and white. House in castles built atop the highest mountains or floating in cloud banks.
- Cannot be surprised due to its keen sight and smell.
- Strong winds constantly surround it, Impairing projectile attacks.
