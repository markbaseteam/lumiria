---
dg-publish: true
tags: creature/type/monsterous creature/type/humanoid 
---

# Giant Crab

6 HP, 3 Armor, 14 STR, 3 DEX, 8 WIL, pincers (d12)

- Huge crustaceans that live in coastal areas and mindlessly attack anything that comes near.
- Their pincers crush with enough strength to ignore any armor lesser than plate. 
- Their heavy carapace makes them notably hardy but equally slow.
