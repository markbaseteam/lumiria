---
dg-publish: true
tags: creature/type/monsterous creature/type/humanoid 
---

# Fire Giant

13 HP, 3 Armor, 17 STR, 8 DEX, greatsword (d12+d10)

- 16’ tall humanoids with red hair and charcoal skin. Wear heavy armor made of brass, bronze or copper. Lair in fortresses built near volcanoes.
- Masters of craft and war, know how to forge the finest weaponry.
- Immune to fire and heat.
