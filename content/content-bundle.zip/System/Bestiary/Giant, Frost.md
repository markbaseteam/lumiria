---
dg-publish: true
tags: creature/type/monsterous creature/type/humanoid 
---

# Frost Giant 

14 HP, 2 Armor, 18 STR, 12 WIL, greataxe (d12+d10) or longbow (d12)

- 18’ tall humanoids with blue-ish skin and pale hair. Wear furs and iron Armor.
- Unharmed by cold and ice.
- Excellent trackers, hunt accompanied by dire wolves.
