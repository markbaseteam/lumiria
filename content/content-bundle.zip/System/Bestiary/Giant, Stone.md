---
dg-publish: true
tags: creature/type/monsterous creature/type/humanoid 
---

# Stone Giant

12 HP, 2 Armor, 15 STR, 15 DEX, stone club (d8+d8) or rocks (d12)

- 14’ tall slender humanoids with stone-like gray skin.   Dwell in caverns or build homes of stone in valleys.
- Preffer attacking by throwing rocks from far away, only fighting on melee if cornered.
- Can easily camouflage into stone, hiding to avoid direct confrontation.
