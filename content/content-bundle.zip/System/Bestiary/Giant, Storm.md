---
dg-publish: true
tags: creature/type/monsterous creature/type/humanoid 
---

# Storm Giant

18 HP, 2 Armor, 18 STR, 16 DEX, 18 WIL, greatsword (d12+d10), _detachment_

- 25’ tall humanoids with bronze-hued skin and light-colored hair. Live in mountain peaks and sometimes rocky coastlines.
- Unharmed by lightning, can summon storm clouds at their will.
- Able to fly along the winds at a slower pace.
- **Lightning Bolt**: The giant crashes a powerful lightining at a point within its reach, dealing d12 blast damage that ignores armor. It needs a short rest before being able to do it again.
