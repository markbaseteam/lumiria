---
dg-publish: true
tags: creature/type/monsterous creature/type/canine 
---

# Gnoll

6 HP, 1 Armor, 12 STR, 8 WIL, spear (d8) or short bow (d6)

- Ferocious humanoid hyenas.   Legend says they were created in a wizard’s experiments.
- Attack in packs, intimidating its victims with numbers.
- **Critical Damage**: the gnoll enters in a rampage after tasting blood, making another attack immediately.
