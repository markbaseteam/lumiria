---
dg-publish: true
tags: creature/type/humanoid 
---

# Gnome

4 HP, 8 STR, 12 DEX, 14 WIL, crossbow (d8, bulky)

- Short humanoids with long noses and ears.   Live underground or deep in forests.
- Intelligent tinkers, love messing with any kind of mechanism. Can easily be convinced by the promise of something novel or uncommon.
- Can understand and communicate with small mammals like moles or squirrels.
