---
dg-publish: true
tags: creature/type/humanoid creature/type/monsterous 
---

# Goblin

4 HP, 8 STR, 12 DEX, 8 WIL, dagger (d6) or sling (d4)

- Small, grotesque humanoids with skin in earthly tones of green, brown, and grey.
- Avoid combat, only attacking when in advantage, using hit-and-run tactics.
- Sometimes are found using dire wolves as mounts.
