---
dg-publish: true
tags: creature/type/construct creature/type/humanoid 
---

# Golem, Original

16 HP, 2 Armor, 15 STR, 6 DEX, 2 WIL, cobblestone fists (d10)

- A hulking 9’ tall statue made of clay, mud, and prayer.
- Mindlessly follows whatever commands given by its master, even after their death.
- Immune to mundane blades and missile weapons. Damage from fire is __enhanced__.
- If destroyed, the Golem eventually reforms and carries out its previous orders.
