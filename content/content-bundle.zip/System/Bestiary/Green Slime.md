---
dg-publish: true
tags: creature/type/monsterous 
---

# Green Slime

3 HP, 18 STR, 6 DEX, 3 WIL, acidic touch (d10+d8)

- Large blobs of green slime that stick to walls and ceiling. Attack by dropping on top of their victims.
- The acid corrodes both metal and wood along with the carrier, but cannot affect stone. Consumed flesh becomes more green slime.
- Immune to all damage except fire. Once stuck on a victim, can only be removed if burned away.
