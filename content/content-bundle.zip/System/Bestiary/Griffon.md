---
dg-publish: true
tags: creature/type/monsterous 
---

# Griffon

7 HP, 14 STR, 15 DEX, beak (d8+d8) or claws (d6, blast)

- Ravenous hybrid predators, with the head and wings of an eagle and the lower body of a lion.
- Fly and attack at astonishing speeds, being able to dive for an attack and fly away before the target can react.
- Can be used as a mount if taken young and properly trained.
