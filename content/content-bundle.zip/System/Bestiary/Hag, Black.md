---
dg-publish: true
tags: creature/type/humanoid creature/type/magical 
---

# Black Hag

10 HP, 12 STR, 16 WIL, talons (d8+d6)

- Hideous, 8' tall creatures that reassemble female humans of old age with blue-black skin. Their talons and teeth are hard like iron.
- Dwell in dead forests and swamps, crave eating human flesh.
- Can cloak their true appearance with an illusory form, and can see through any illusion.
- Avid magic users, each Hag carries 1d4 random spellbooks. 
