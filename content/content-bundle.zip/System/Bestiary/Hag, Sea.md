---
dg-publish: true
tags: creature/type/humanoid creature/type/magical 
---

# Sea Hag

6 HP, 12 STR, 14 WIL, knife (d6)

- Ghostly looking, green-skinned hags that dwell in seaweed forests and warm shallow waters. Crave eating human flesh.
- Highly resistant to magic effects.
- **Hideous Gaze**: Everyone facing the Hag must save WIL or drop to 0 HP, each target can only be affected once per encounter.
