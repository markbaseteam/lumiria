---
dg-publish: true
tags: creature/type/humanoid 
---

# Halfling

4 HP, 8 STR, 14 DEX, 14 WIL, shortswords (d6+d6)

- Small humanoids with hairy feet live in small settlements called shires.
- Highly resistant to fear effects.
- Each shire is led by a stronger halfling called shire-riff, who has access to better equipment.
