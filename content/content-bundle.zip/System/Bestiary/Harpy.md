---
dg-publish: true
tags: creature/type/monsterous 
---

# Harpy

8 HP, 12 DEX, 14 WIL, claws (d6+d6) or song (save)

- Hideous monstrosities with the body of a giant eagle and a humanoid head.
- Its movements and flight are clumsy due to its unproportional size. Rely on charmed victims to do anything of note. 
- **Charming Song**: Anyone who hears the song of a harpy must save WIL or be charmed, following the harpy and defending it from any threat. The charm is broken when the victim leaves the harpy's presence. 
