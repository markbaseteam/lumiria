---
dg-publish: true
tags: creature/type/birds creature/type/wild-animal 
---

# Giant Hawk

10 HP, 8 STR, 15 DEX, 8 WIL, talons and beak (d8+d6)

- Large birds of prey, the size of a wolf. Can carry animals up to their size.
- Hunt animals that they can carry, but might attack humans or greater prey if despaired.
- Surprise their victims by diving to attack from a great height.
- Can supposedly be trained to be hunting companions. 
