---
dg-publish: true
tags: creature/type/canine creature/type/monsterous 
---

# Hellhound

8 HP, 12 STR, 15 DEX, bite (d8+d6) or fire breath (d8)

- Monstrous, intelligent dogs with the size of a large wolf. Dwell near volcanoes and sometimes accompany other fire-related creatures.
- Immune to fire and heat, its insides are hot enough to melt iron if it is swallowed.
- Don't rely on sight to find its foes, due to its keen sense of smell.
