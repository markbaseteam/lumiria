---
dg-publish: true
tags: creature/type/humanoid 
---

# Hobgoblin

6 HP, 2 Armor, 14 STR, 8 DEX, mace (d8)

- Large and burly relatives of goblins. Dwell in underground fortresses, but frequently march in aboveground campaigns.
- Strongly lawful and militarized culture, follow orders without question.
- Automatically succeed in Morale Saves if a commander is present. 
- Trained to fight together, damage dealt is _enhanced_ if an ally is also engaged with the same enemy.
