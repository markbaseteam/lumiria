---
dg-publish: true
tags: creature/type/humanoid 
---

# Hooded Men

12 HP, 9 STR, 12 DEX, 14 WIL, leystaff (d8), a Spellbook (Choose one: _Charm, Hypnotize, Push/Pull, Shield_)

- The Watchers of the Wood; a cult that derive their power from leylines, rune stones, and the like.
- Critical damage: leech a part of the victim's soul (1d4 WIL damage).
