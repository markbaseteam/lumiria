---
dg-publish: true
tags: creature/type/monsterous creature/type/reptilian 
---

# Hydra

18 HP, 2 Armor, 15 STR, 12 WIL, bite (d12, blast)

- A large reptilian creature with nine serpentine heads. Can attack a number of targets equal to the number of heads.
- Each time it takes damage to STR, loses one head. Severed heads regrow after one turn, recovering 1d4 HP for each head regrown.
- Fire damage received is _enhanced_, and stops head regrowth for a turn.
