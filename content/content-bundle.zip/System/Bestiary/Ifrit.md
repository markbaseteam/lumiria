---
dg-publish: true
tags: creature/type/elemental creature/type/magical 
---

# Ifrit

10 HP, 15 STR, 14 WIL, flaming sword (d10+d8, bulky)

- Clever, treacherous beings from the elemental plane of fire. Manifest as huge men with terrifying faces and an aura of heat and smoke.
- Might be summoned by powerful magic and ordered to complete tasks, but will subvert commands while following them to the letter.
- **Pillar of Flame**: The Ifrit transforms into a tall, 30' wide column of flame, torching everything touched for d12 damage. It needs a short rest before being able to do it again.
