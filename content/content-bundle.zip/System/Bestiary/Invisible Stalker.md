---
dg-publish: true
tags: creature/type/humanoid creature/type/magical 
---

# Invisible Stalker

8 HP, 12 STR, 12 DEX, 15 WIL, unarmed blows (d6+d4)

- Intelligent beings coalesced from arcane energies into a humanoid shape. Summoned by powerful wizards to perform tasks for them.
- Completely invisible and silent, detecting it is virtually impossible.
- If killed, the energies disperse and can later be reformed by its summoner. 
