---
dg-publish: true
tags: creature/type/insect creature/type/monsterous 
---

# Killer Bees

6 HP, 6 STR, 14 DEX, 8 WIL, sting (d6), _detachment_

- Oversized bees that build underground hives. Hyper aggressive, attack anything that comes near.
- Produce special honey that can heal d6 HP once per day if consumed.
- When the bees cause STR damage, the sting is lodged into the target, dealing d4 damage each round until removed.
