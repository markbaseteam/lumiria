---
dg-publish: true
tags: creature/type/humanoid creature/type/canine 
---

# Kobold

3 HP, 8 STR, bite (d6)

- Small canine humanoids with hairless, scaly, red-brown skin. Can see perfectly in the dark, but are harmed by direct sunlight. 
- Fight dirty, ambushing their victims in cramped spaces and running away as soon as the tide turns. Try to ambush adventurers and take their possessions. 
- **Critical Damage**: The Kobold bites a off a chunk of flesh from the target.
