---
dg-publish: true
tags: creature/type/humanoid creature/type/serpent creature/type/monsterous 
---

# Lamia

9 HP, 14 STR, 14 WIL, claws and bite (d8+d6)

- Centaur-like monsters with the head and upper body of a woman and the lower body of a scaled beast. Prey on humanoids, drinking their blood and eating their flesh.
- Can disguise their true form with illusions, appearing as a human woman.
- Critical Damage: The lamia saps the victim's wisdom (d6 WIL damage). A victim who reaches 0 WIL this way mindlessly obeys the lamia's commands.
