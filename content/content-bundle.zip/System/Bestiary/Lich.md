---
dg-publish: true
tags: creature/type/humanoid creature/type/magical 
---

# Lich

18 HP, 1 Armor, 18 WIL, soul dagger (d8)

- Powerful wizards who refused death by turning themselves in soulless undead.
- Able to cast virtually any spell without suffering consequences. Carries 2d6 random spellbooks with them.
- **Critical Damage**: The target is paralyzed until it fully rests.
