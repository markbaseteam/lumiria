---
dg-publish: true
tags: creature/type/humanoid creature/type/reptilian 
---

# Lizard Man

5 HP, 1 Armor, 14 STR, 12 DEX, bone spear (d8)

- Tribal amphibian humanoids with reptilian heads and tails. Dwell in jungles nearby large bodies of water.
- Craft their armor and weapons from the bones of their prey.
- Carnivorous, eat even the flesh of other humanoids as a display of power.
