---
dg-publish: true
tags: creature/type/monsterous creature/type/humanoid 
---
# Manticore

6 HP, 15 DEX, 12 WIL, claws (d4+d4) or tail spike (d6)

- Monstrosities with a human face, a lion body, bat wings, and a spiked tail. Dwell in mountainous regions.
- Prey on humans, following them and attacking with the spikes when they see an opening.
- Attack with their tails by throwing the spikes like darts. The spikes regrow after a few days.
