---
dg-publish: true
tags: creature/type/insect creature/type/monsterous 
---

# Giant Mantis

10 HP, 1 Armor, 14 DEX, 12 WIL, claws (d8+d6)

- 10' long insects with clawed forelimbs and slicing mandibles. Dwell in warm forests and jungles.
- Hunt any prey, using their green coloration to camouflage in the foliage. Will not attack obviously stronger foes.
- **Critical Damage**: Locks the victim in their claws, and bites their head off.
