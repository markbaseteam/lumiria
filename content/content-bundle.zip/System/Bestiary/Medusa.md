---
dg-publish: true
tags: creature/type/humanoid creature/type/magical 
---

# Medusa

10 HP, 8 STR, 12 DEX, 16 WIL, snake bites (d6+d4) or gaze (save)

- Magical creatures that look like women with snakes in place of hair.
- Clever and proud, but reasonable. Will let adventurers go free if they somehow please its ego.
- **Gaze**: Anyone who looks directly at the medusa's face must save WIL or be turned to stone. Averting eyes from the face prevents this effect, but impairs any damage dealt.
- Targets turned into stone can be recovered by a willing kiss of the medusa, or by being bathed in its blood. The blood of a medusa is only enough to recover a single victim.
