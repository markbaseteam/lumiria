---
dg-publish: true
tags: creature/type/shapeshifter creature/type/monsterous 
---

# Mimic

9 HP, 2 Armor, 13 STR, 12 WIL, bite (d12)

- Monstrous shape-shifters that take on the form of inanimate objects made of wood and stone. Found only underground.
- Remain motionless (generally in the form of chests or doors), devouring anything that touches it.
- The mimic's saliva is extremely sticky, taking great strength to remove something from its mouth once glued.
