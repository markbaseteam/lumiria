---
dg-publish: true
tags: creature/type/humanoid creature/type/monsterous 
---

# Mind Lasher

12 HP, 8 STR, 12 DEX, 18 WIL, tentacles (d6+d4), or mind blast (save)

- Humanoid creatures with purple skin and an octopus-like head. Dwell deep underground, plotting to enslave humanity. Feed on the brains of other humanoids.
- **Mind Blast**: Emits a frequency that affects the brains of nearby creatures, all caught must save WIL or be paralysed.
- **Critical Damage**: The tentacle rips the victim's brain out of the skull, and the mind lasher eats it, gaining all of the victim's memories.
