---
dg-publish: true
tags: creature/type/humanoid creature/type/monsterous 
---

# Minotaur

12 HP, 1 Armor, 16 STR, 8 WIL, axe (d10) or horns (d6+d6)

- A large, muscular humanoid with the head of a bull. Generally lair in a maze or dungeon, making the whole place it's territory.
- Notably strong, is able to easily break stone, which it uses to alter the enviromment and separate its foes to kill then one by one.
- If the minotaur suceeds in a Critical Damage save, it is driven into a bloodthirsty state, enhancing all its attacks and impairing all attacks agaisnt it. Only stops when killed or if it no longers sees any foe.
