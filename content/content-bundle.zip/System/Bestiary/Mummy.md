---
dg-publish: true
tags: creature/type/undead creature/type/humanoid 
---

# Mummy

6 HP, 12 STR, 8 DEX, 6 WIL, infected touch (d10)

- Undead humanoids wrapped in funerary bandages. Found in ruins of temples and tombs.
- The first time anyone sees the mummy, it must save WIL or be paralyzed. The paralysis ends immediately if the mummy attacks or goes out of sight.
- **Critical Damage**: The mummy inflicts a disease that rots open wounds, making them impossible to heal normally. Can only be removed by magic.
