---
dg-publish: true
tags: creature/type/monsterous 
---

# Nightmare

8 HP, 15 STR, 12 DEX, 18 WIL, flaming hooves (d8+d6)

- Intelligent demonic horses with burning-red eyes, smoldering nostrils, and flaming hooves.
- Constantly breathe a thick cloud of smoke, impairing damage dealt by anyone in melee with the nightmare.
- Sometimes are used as steeds by other powerful demonic creatures.
