---
dg-publish: true
tags: creature/type/monsterous 
---

# Giant Octopus

8 HP, 14 STR, 8 WIL, tentacles (d6, blast)

- Large, eight-armed saltwater creatures. Dwell nearby warm coasts.
- Can attack up to 8 nearby creatures.
- When threatened, spills a thick cloud of ink and quickly swims away.
