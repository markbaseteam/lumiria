---
dg-publish: true
tags: creature/type/wild-animal creature/type/monsterous 
---

# Owl Bear

9 HP, 16 STR, beak (d10) or claws (d8+d6)

- Huge, carnivorous bear-like creatures with the face of an owl. Found in dense forests.
- Excellent trackers, can detect even the slighest signs of prey.
- Highly territorial, attack anything that comes too close.
- **Critical Damage**: Maul the target, crushing armor and tearing a limb apart.
