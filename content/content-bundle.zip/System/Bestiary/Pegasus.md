---
dg-publish: true
tags: creature/type/magical creature/type/wild-animal creature/type/equine
---

# Pegasus

6 HP, 12 STR, 15 DEX, 15 WIL. hooves (d6+d6)

- A intelligent winged horse, wilful and proud. Seen as a symbol of beauty and nobility.
- Have a rigid sense of morality and can feel if a person has broken it.
- Will offer to help adventurers as a mount if it judges the person's cause as noble and just. 
