---
dg-publish: true
tags: creature/type/magical creature/type/birds 
---

# Phoenix

18 HP, 12 STR, 18 DEX, 18 WIL, talons (d12+d10)

- Giant eagle-like birds made of pure flame, found in isolated regions and only attack in self-defense.
- Posesses simple intelligence and watches travellers carefully to judge if they are a threat.
- Its feathers are capable to heal any disease, but cannot be taken, only given by the phoenix.
- Unharmed by fire and heat. Emits an aura of fire that does d8 damage to anyone that comes nearby.
- If killed, disappears into a small sphere of flames. After a turn, it is reborn from its ashes and flees.
