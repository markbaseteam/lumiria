---
dg-publish: true
tags: creature/type/humanoid creature/type/magical 
---

# Pixie

6 HP, 3 STR, 18 DEX, 15 WIL, dagger (d6)

- Tiny humanoids with insectoid wings. Close relatives of fairies.
- Extremely agile, it's impossible to simply attack one with a weapon.
- Naturally invisible, can reveal itself if it chooses to.
- Its mall wings only allow it to fly for short periods of time before needing to rest.
