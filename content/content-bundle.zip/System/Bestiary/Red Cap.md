---
dg-publish: true
tags: creature/type/humanoid creature/type/fae creature/type/magical 
---

# Red Cap

6 HP, 12 DEX, 8 WIL, two sickles (d6+d6)

- Borne from blood left to rot in the fae. Hats colored by blood; they even bathe in blood.
- Attack travelers, but will ignore those with little to live for, as there is no pleasure in it.
- **Critical Damage**: eviscerate the target, showering in blood, restoring any lost STR & HP.
