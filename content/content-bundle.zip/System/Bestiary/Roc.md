---
dg-publish: true
tags: creature/type/birds creature/type/monsterous 
---

# Roc

18 HP, 18 STR, 14 DEX, 12 WIL, claws (d8+d8, blast) or bite (d10+d10), _detachment_

- Gargantuan birds of prey that nest atop the highest peaks and attack anything that approaches their nests. Considered myths by most people.
- Surprise victims by swooping down from above.
- Legend says that if someone steals a egg and nurses until it hatches, the bird will whisper powerful knowledge to the caretaker before flying away.
