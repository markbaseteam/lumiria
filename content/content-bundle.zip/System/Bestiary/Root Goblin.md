---
dg-publish: true
tags: creature/type/humanoid 
---

# Root Goblin

4 HP, 8 STR, 14 DEX, 8 WIL, spear (d6)

- Avoid combat unless they have the advantage (such as greater numbers).
- Guard their stolen goods to the death.
- Prize Spellbooks; willing to trade.
