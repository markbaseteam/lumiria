---
dg-publish: true
tags: creature/type/humanoid 
---

# Root Witch

8 HP, 9 STR, 16 DEX, 14 WIL, tuber-fingers (d6)

- Excellent tunneler that hides underground near water. Wiggles tiny fronds into the air as lures.
- Above-ground, appears vaguely humanoid with the face of a rotted tree stump.
- Will exchange rare minerals for a “fresh corpse” of any kind.
