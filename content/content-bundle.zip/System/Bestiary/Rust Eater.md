---
dg-publish: true
tags: creature/type/monsterous 
---

# Rust Eater

5 HP, 12 DEX, 12 WIL, bite (d6)

- Armadillo-like creatures with long tails and two long antennae. Feed on rusted metal.
- Any metal that touches its antennae instantly becomes rust. Relics are partially resistant to this effect.
- Can smell metal from a long distance.
