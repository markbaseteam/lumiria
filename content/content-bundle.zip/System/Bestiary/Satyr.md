---
dg-publish: true
tags: creature/type/humanoid creature/type/magical 
---

# Satyr

6 HP, 12 DEX, 16 WIL, horns (d6) or pipes (save)

- Magical humanoids with the legs and horns of a goat that love to dance and drink. Found in deep forests.
- Highly resistant to magic effects.
- **Pipes**: Anyone who hears the music from a satyr's pipes must save WIL or fall asleep, be charmed or frightened. The Satyr chooses which effect when playing the pipes.
