---
dg-publish: true
tags: creature/type/arachnid creature/type/monsterous 
---

# Giant Scorpion

8 HP, 2 Armor, 12 DEX, 8 WIL, claws (d10+d8) or sting (d8)

- Huge arachnids, the size of a horse, with pincers and poisonous stingers. Found in drylands and caverns. Highly aggressive, normally attack on sight.
- Immobilizes its victims with the claws, and then attack with the sting.
- **Critical Damage**: The sting’s poison paralyzes  the target, killing it in one day if not treated.
