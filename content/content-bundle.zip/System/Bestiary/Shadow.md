---
dg-publish: true
tags: creature/type/monsterous 
---

# Shadow

6 HP, 8 STR, 14 WIL, draining touch (d6, ignores armor) 

- Incorporeal monsters that look like animated shadows.
- Unharmed by mundane attacks, sleep or mind control.
- **Critical Damage**: The target loses another d4 STR, if reduced to 0 STR, they become a shadow.
