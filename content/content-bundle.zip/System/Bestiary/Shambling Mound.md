---
dg-publish: true
tags: creature/type/monsterous 
---

# Shambling Mound

9 HP, 15 STR, 6 DEX, 8 WIL, tendrils (d8+d8)

- Plant monsters with the rough shape of a 9' tall humanoid made of slimy vegetation. Dwell in dark swamps and damp undergrounds.
- Damage from mundane weapons are _impaired_.
- Grapples its targets and tries to drow them in water bodies.
