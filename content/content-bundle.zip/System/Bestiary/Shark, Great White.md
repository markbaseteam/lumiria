---
dg-publish: true
tags: creature/type/monsterous 
---

# Great White Shark

8 HP, 14 STR, 14 DEX, 6 WIL, bite (d10+d10)

- 30' long aggressive fish of a grey coloration. Dwell deep salt water, and sometimes attack smaller boats.
- Can detect the smell of blood from many miles away.
- Once moves to attack, doesn't stop until death.
