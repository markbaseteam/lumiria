---
dg-publish: true
tags: creature/type/undead 
---

# Skeleton

5 HP, 1 Armor, 13 DEX, rusty sword (d6)

- If a skeleton is killed and its bones are not scattered, it reforms.
