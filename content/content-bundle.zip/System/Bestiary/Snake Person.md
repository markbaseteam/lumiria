---
dg-publish: true
tags: creature/type/serpent creature/type/humanoid 
---

# Snake Person

6 HP, 1 Armor, 12 DEX, 14 WIL, bite (d6)

- Creatures with the body, tail, and head of a giant snake and scaled humanoid torso and arms. Capture other humanoids to be eaten or enslaved by their cruel masters. Dwell in hot jungles.
- Highly resistant to magic effects.
- Supposedly can breed with humans, creating hybrids that have the appearance of humans with reptilian eyes and forked tongues.
