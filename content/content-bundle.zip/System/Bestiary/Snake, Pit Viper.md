---
dg-publish: true
tags: creature/type/serpent creature/type/wild-animal 
---

# Snake, Pit Viper

3 HP, 12 DEX, bite (d6)

- 5' long snakes with greyish scales, found in caves and other dark places.
- Does not rely on vision, instead, senses its victims by their body heat.
- **Critical Damage**: The poison kills the target in a day if a antidote isn't applied.
