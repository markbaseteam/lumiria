---
dg-publish: true
tags: creature/type/serpent creature/type/wild-animal 
---

# Snake, Spitting Cobra

3 HP, 14 DEX, acid spit (d6)

- 3' long snake with grey and white scales. Notably shy, live in places where they can blend in.
- Attack from distance with their acidic spit, always aiming for the head of the target.
- **Critical Damage**: The acid corrodes the target's face, permanently damaging its visage and senses.
