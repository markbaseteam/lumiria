---
dg-publish: true
tags: creature/type/monsterous 
---

# Sphinx

12 HP, 12 STR, 15 WIL, claws (d8+d6) or roar (save)

- Large monsters with bird wings, the body of a lion, and a human face. Collect puzzles, riddles, and obscure knowledge. Might pose riddles to those they meet, attacking and consuming any who cannot give the correct answer.
- **Roar**: Anyone who hears the sphinx's roar must save WIL or flee in fear.
- Carry 1d4 spellbooks with them, prefering magic related to knowledge or communication, but taking any.
