---
dg-publish: true
tags: creature/type/arachnid creature/type/monsterous 
---

# Giant Phase Spider

6 HP, 14 DEX, 12 WIL, bite (d6)

- 8’ long, black spiders that have the ability to become intangible. Dwell in web-filled lairs and sometimes prey on humans.
- Can freely shift in and out of existence. When threatened, phases out and only phases in for a seceond when it attacks. 
- **Critical Damage**: The poison kills the target in a day if not treated.
