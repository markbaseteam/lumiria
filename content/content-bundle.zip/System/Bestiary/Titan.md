---
dg-publish: true
tags: creature/type/humanoid 
---

# Titan

18 HP, 2 Armor, 16 STR, 12 DEX, 18 WIL, sword (d12+d10)

- 20’ tall humanoids of radiant beauty and athletic build. Beneficent of character, but prone to megalomania. Natives of other planes, but sometimes have strongholds in the mortal world.
- Can levitate at will, with precise control of its movement.
- Masters of spellcasting, carry 2d6 spellbooks and can always enchance spell effects without risk or need to prepare for it.
