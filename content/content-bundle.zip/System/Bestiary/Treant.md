---
dg-publish: true
tags: creature/type/monsterous 
---

# Treant

10 HP, 3 Armor, 15 STR, 3 DEX, 12 WIL, roots (d10+d8, blast)

- A human face made of bark on the trunk of a massive tree. Found in the center of thick forests where it spreads its massive roots.
- Connected to all trees on its forest, can control their growth and move their branches.
- It feeds by draining energy from fresh bodies, any amount can be used, but the mightier the creature the better.
