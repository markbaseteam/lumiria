---
dg-publish: true
tags: creature/type/humanoid 
---

# Triton

6 HP, 12 STR, 12 DEX, 12 WIL, trident (d8)

- Aquatic humanoids with silvery skin, blue-green hair, and scaled legs ending in fins. Dwell in warm waters both at shallows and at great depths.
- Extremely proud, consider themselves a better version of any other folk, going through great efforts to prove so.
- Lair in beautiful castles sculpted from sea rocks and corals, guarded by other sea creatures under their command.
