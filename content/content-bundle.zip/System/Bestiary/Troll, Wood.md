---
dg-publish: true
tags: creature/type/humanoid creature/type/monsterous 
---

# Wood Troll

10 HP, 15 STR, 12 DEX, 7 WIL, claws and bite (d8+d8, blast)

- Large humanoid beings with alongated arms. Live in forests, sharing a deep connection with the vegetation around it.
- As an action the troll can eat a handful of moss to fully recover its HP.
- **Critical Damage**: Moss and twigs begin growing out of target's wounds.
