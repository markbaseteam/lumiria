---
dg-publish: true
tags: creature/type/humanoid creature/type/monsterous 
---

# Troll

6 HP, 1 Armor, 14 STR, 12 DEX, talons and bite (d10+d6)

- Wicked, 8’ tall humanoids with rubbery bodies. Consume the flesh of other humanoids. Dwell underground, in the barren wilderness, and in the ruined homes of former victims.
- Fire and acid damage received is _enhanced_, and stops a troll's regeneration. When attacked with either of those, the troll fails all morale checks.
- Regains 3 HP per round, and even severed limbs are reattached. If killed, will regenerate and fight again in an hour.
