---
dg-publish: true
tags: creature/type/reptilian 
---

# Tyrannosaurus

18 HP, 1 Armor, 18 STR, 12 DEX, bite (d10+d10), _detachment_

- Massive, two-legged, predatory reptiles with huge jaws.
- Extremely rare, can only be found in large regions of untouched wilderness.
- Only hunt large and dangerous prey, always attacking the most threatening foe first.
