---
dg-publish: true
tags: creature/type/equine creature/type/wild-animal 
---

# Unicorn

6 HP, 12 DEX, 14 WIL, horn (d10, ignores armor)

- Magical horses with a single long horn on its foreheade. Timid, but proud and wilful, are seen as divine beings.
- Its hairs are worth small fortunes due to its powerful healing properties.
- Can teleport to any place in its sight once a day.
