---
dg-publish: true
tags: creature/type/humanoid creature/type/undead 
---

# Vampire

12 HP, 1 Armor, 14 STR, 12 DEX, 16 WIL, bite (d10)

- Charming, undead creatures that drink the blood of mortals. Act at night and sleep in a coffin during the day. Can change its form to the one of a bat.
- **Regeneration**: A damaged vampire regains 6 HP when it bites a target that has blood. If killed, it becomes a cloud of gas and retreats to its coffin, reforming at the next nightfall. Can only be killed if exposed to sunlight or if the coffin is destroyed.
- **Critical Damage**: The vampire drains the targets's essence, dealing d12 damage to WIL. If the target reaches 0 WIL this way, it dies and is raised as a thrall of the vampire
