---
dg-publish: true
tags: creature/type/feline creature/type/monsterous 
---

# Warper

8 HP, 14 DEX, 12 WIL, tentacles (d8, blast)

- Large panther like predators with many edged tentacles growing out of their backs.
- Can teleport short distances at will, which it uses to ambush prey.
- Highly resistant to magical effects.
