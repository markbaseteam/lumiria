---
dg-publish: true
tags: creature/type/wild-animal creature/type/monsterous 
---

# Giant Weasel

6 HP, 15 STR, 14 DEX, bite and claws (d12+d10)

- 6’ long, predatory mammals with rich fur of brown, gold, or white. Dwell in subterranean tunnels, hunting alone or in small groups.
- Vicious trackers, can smell blood at long distances. Prefer to stalk targets that are already wounded to finish them off.
- After attacking, locks its powerful jaws on the target and keeps biting, only releasing if its sure the victim is dead.
