---
dg-publish: true
tags: creature/type/canine creature/type/humanoid creature/type/monsterous 
---

# Werewolf

8 HP, 15 STR, 14 DEX, 6 WIL, claws (d6+d6) or bite (d8)

- Ferocious humanoid and wolf hybrids that hunt with abandon. Created by a curse being placed in a human or a wolf.
- Its piercing howls can be heard for miles away, and are capable of calling regular wolves to its aid.
- Mundane attacks are _impaired_ against the werewolf, but weapons made of silver are _enhanced_.
- **Critical Damage**: The target becomes infected, transforming into a werewolf by the next full moon.
