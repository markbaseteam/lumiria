---
dg-publish: true
tags: creature/type/canine creature/type/monsterous 
---

# Dire Wolf

8 HP, 14 STR, 12 DEX, bite (d10)

- Horse-sized, semi-intelligent wolves. Highly territorial, live in forests or mountains and ferociously guards its surroundings.
- Regular wolves are scared of them, but will fight alongside them against invaders.
- Can be trained like dogs if captured young, but it's a extremely difficult challenging.
