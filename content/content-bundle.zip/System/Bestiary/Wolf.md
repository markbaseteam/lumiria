---
dg-publish: true
tags: creature/type/canine creature/type/wild-animal 
---

# Wolf

6 HP, 12 STR, 14 DEX, bite (d8)

- Large canines that dwell primarily in wildlands, but occasionally lair in caves.
- Can be trained like dogs if captured young.
- When found in packs of at least 4, wolfs never fail morale saves. 
