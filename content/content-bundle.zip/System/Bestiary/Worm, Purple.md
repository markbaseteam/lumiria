---
dg-publish: true
tags: creature/type/monsterous 
---

# Purple Worm

18 HP, 1 Armor, 18 STR, 8 DEX, 6 WIL, bite (d10+d10), _detachment_

- Gargantuan worms with bodies more than 100' long and 10' thick. Burrow in tunnels underground and surface to eat other creatures. Found in deserts and other drylands.
- Victims that save against Critical Damage caused by the worm are swallowed whole. Anything inside the worm receives d12 acid damage each round.
- **Critical Damage**: The target is devoured and crushed inside the worm.
