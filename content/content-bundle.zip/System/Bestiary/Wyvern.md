---
dg-publish: true
tags: creature/type/reptilian 
---

# Wyvern

7 HP, 14 DEX, bite (d8+d8) or poisonous sting (d6)

- Winged, two-legged, reptilian monsters with a long tail tipped with a venomous sting. Dwell in any terrain, but favor dry cliffs.
- Shy away from other creatures, but attacks anything that comes in the vicinity of its nest.
- **Critical Damage**: The deadly poison permanently debilitates the target, reducing its maximum STR to the current value. 
