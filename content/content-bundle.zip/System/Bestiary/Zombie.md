---
dg-publish: true
tags: creature/type/undead creature/type/humanoid 
---

# Zombie

6 HP, 6 DEX, 3 WIL, rusted weapon (d6)

- Slow, mindless re-animated corpses. Created by wicked wizards to serve as guardians in hordes.
- Simply attacks anything that comes nearby.
- Cannot be affected by anything that targets the mind.
